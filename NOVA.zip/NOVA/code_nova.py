# -*- coding: utf-8 -*-
"""
Created on December 12 2024

@author: nborri

The data is organized as follows:
    
The file contains monthly data on asset excess returns and factors.
The dates are in columns yyyymm. The asset and factor names are in
columns id. The factors are:

'Mkt-RF', 'SMB', 'HML', 'RMW', 'CMA', 'Mom',
'dp_macro','ep_macro','b/m','ntis','tbl','tms','dfy','svar'

The assets are the remaining ids and always start with p (for example,
p1_strev, etc,) for portfolio 1 and a given strategy.
"""

# ** Import libraries **
import numpy as np
import pandas as pd
import statsmodels.api as sm
import itertools
from statsmodels.stats.sandwich_covariance import cov_hac
import matplotlib.pyplot as plt

# OPTION DATA

FILENAME = './OUT/data_test_anatolii_09042024.csv'  
    
df = pd.read_csv(FILENAME)

# ** Factors ** 
ff1 = ['Mkt-RF']
ff3 = ['Mkt-RF', 'SMB', 'HML']
ff5 = ['Mkt-RF' ,'SMB', 'HML', 'RMW', 'CMA']
other_factors = ['Mom','dp_macro','ep_macro','b/m','ntis','tbl','tms','dfy','svar']

# ** Drop rows where 'id' is in other_factors **
df = df[~df['id'].isin(other_factors)]

# List of test assets
assets = df[~df['id'].isin(ff5)]['id'].unique().tolist()

# Option to include or exclude intercept in predictions
use_intercept = True  # Set to False to exclude intercept

# #################### #
# ESTIMATION FF1 MODEL
# #################### #

# >> Estimate plain-vanilla CAPM 1-factor model in cross-section <<

# This is the first-step of a two-pass FMB regression method

# Extract factor data for independent variables
factor_data = df[df['id'].isin(ff1)].pivot(index='yyyymm', columns='id', values='exret')
factor_data = sm.add_constant(factor_data)  # Add a constant for the intercept

# Initialize an empty list to store results for "linear + squared + interaction terms" model
results_list = []
prediction_list = []

# Loop over each asset for the "linear" model
for asset in assets:
    # Filter data for the specific asset
    asset_data = df[df['id'] == asset]
    asset_returns = asset_data.set_index('yyyymm')['exret']
    
    # Align the dates of asset returns with factor data including squared and interaction terms
    aligned_data = factor_data.join(asset_returns, how='inner')
    
    # Define independent variables (the factors and the constant)
    X = aligned_data[['const'] + ff1]
    
    # Define dependent variable (returns for the asset)
    y = aligned_data['exret']
    
    # Fit the OLS regression model
    mod = sm.OLS(y, X).fit()
    
    # Store the intercept, coefficients, squared, and interaction term coefficients in a dictionary
    coefficients = {'asset': asset, 'intercept': mod.params['const']}
    coefficients.update(mod.params[ff1].to_dict())
    #coefficients_extended.update({term: model_extended.params[term] for term in squared_terms + interaction_terms})
    
    # Append the coefficients dictionary to the results list
    results_list.append(coefficients)
    
    # Make predictions
    aligned_data['exret_predict'] = mod.predict(X)
    
    # Store the predicted values for this asset
    aligned_data['id'] = asset
    prediction_list.append(aligned_data[['id', 'exret', 'exret_predict']])

# Convert the list of dictionaries to a DataFrame
# Store into dataframe OLS slopes + intercepts for each asset
resultsFF1_df = pd.DataFrame(results_list)

# Combine all predicted data
predictionsFF1_df = pd.concat(prediction_list).reset_index()

# ** Scatter Plot **

plt.figure(figsize=(10, 7))
plt.scatter(predictionsFF1_df['exret'], predictionsFF1_df['exret_predict'], alpha=0.7, edgecolors='k')
plt.title('CAPM: Predicted vs Actual Excess Returns')
plt.xlabel('Actual Excess Returns')
plt.ylabel('Predicted Excess Returns')
plt.grid(True)
plt.axline((0, 0), slope=1, color='red', linestyle='--', label='45-degree line')  # Add 45-degree line
plt.legend()

# Save 
#SAVENAME = './OUT/Figure_CAPM_FMB_step1.pdf'
#plt.savefig(SAVENAME, format='pdf')

plt.show()

# Actual vs Predicted
# Independent variable with constant
X = sm.add_constant(predictionsFF1_df['exret_predict'])

# Dependent variable (actual excess returns)
y = predictionsFF1_df['exret']

# OLS regression to compute R-squared
model = sm.OLS(y, X).fit()

# Adjusted R-squared
adjusted_r2 = model.rsquared_adj

# ** Save results in a DataFrame **
prediction_results_df = pd.DataFrame({
    'Model': ['FF1'],
    'R-Squared': [adjusted_r2]
})

# This is the second step of a two-pass FMB regression method
# We run a single cross-sectional regression of mean asset excess returns on the betas from previous step

# Compute mean excess returns for each asset in the test dataset
mean_returns = (
    df[df['id'].isin(assets)] # exclude factors
    .groupby('id')['exret']
    .mean()
    .rename('mean_exret')
    .reset_index()
)

# Merge mean returns with betas estimated from the first step
merged_df = pd.merge(
    mean_returns,
    resultsFF1_df,
    left_on='id',
    right_on='asset'
)

# Define independent variables (betas from the first step)
independent_vars = ff1

# Define dependent variable (mean excess returns)
y = merged_df['mean_exret']

# Define independent variable matrix (betas)
X = merged_df[independent_vars]

# Add a constant to the independent variables
X_with_const = sm.add_constant(X)

# Run the cross-sectional regression
mod = sm.OLS(y, X_with_const).fit()

# Extract adjusted R-squared
adjusted_r_squared = mod.rsquared_adj

# ** Scatter Plot: Predicted vs Actual **
# Compute predicted values
y_pred = mod.predict(X_with_const)

# Create scatter plot
plt.figure(figsize=(10, 7))
plt.scatter(y, y_pred, alpha=0.7, edgecolors='k')
plt.title('CAPM: second step FMB')
plt.xlabel('Actual Mean Excess Returns')
plt.ylabel('Predicted Mean Excess Returns')
plt.grid(True)
plt.axline((0, 0), slope=1, color='red', linestyle='--', label='45-degree line')  # Add 45-degree line
plt.legend()

# Save 
#SAVENAME = './OUT/Figure_CAPM_FMB_step2.pdf'
#plt.savefig(SAVENAME, format='pdf')

plt.show()

# ** Scatter Plot: Beta vs Average Returns **
# This is the SML: Plot it only for CAPM (single beta model)
plt.figure(figsize=(10, 7))

# Select a specific beta
selected_beta = 'Mkt-RF'

# Scatter plot: selected beta (x-axis) vs mean excess returns (y-axis)
plt.scatter(merged_df[selected_beta], merged_df['mean_exret'], alpha=0.7, edgecolors='k', label='Data Points')

# Optionally, add a best-fit line
coeffs = np.polyfit(merged_df[selected_beta], merged_df['mean_exret'], deg=1)
poly_line = np.poly1d(coeffs)
plt.plot(
    merged_df[selected_beta],
    poly_line(merged_df[selected_beta]),
    color='red',
    linestyle='--',
    label='Best Fit Line'
)

# Add title, labels, and grid
plt.title(f'{selected_beta} $\\beta$ vs Average Returns')
plt.xlabel(f'{selected_beta} $\\beta$')
plt.ylabel('Mean Excess Returns')
plt.grid(True)

# Add legend
plt.legend()

# Save 
#SAVENAME = './OUT/Figure_CAPM_FMB_SML.pdf'
#plt.savefig(SAVENAME, format='pdf')

# Show plot
plt.show()

# Compute intercept from repeated cross-sectional regressions
period_interceptsFF1 = []

# Loop over periods in test data
for period, group in df.groupby('yyyymm'):
    # Filter out factors
    group = group[group['id'].isin(assets)]
    
    # Merge asset returns with betas
    group = pd.merge(group, resultsFF1_df[['asset'] + independent_vars], left_on='id', right_on='asset')

    # Prepare dependent variable (excess returns)
    y_period = group['exret']

    # Prepare independent variables (betas)
    X_period = group[independent_vars]  # Use only the betas as independent variables
    X_period_with_const = sm.add_constant(X_period)  # Add constant for intercept

    # Ensure indices are aligned
    y_period = y_period.reset_index(drop=True)
    X_period_with_const = X_period_with_const.reset_index(drop=True)

    # Cross-sectional regression for this period
    period_model = sm.OLS(y_period, X_period_with_const).fit()
    
    # Store the intercept for this period
    period_interceptsFF1.append(period_model.params['const'])

# Compute the average intercept and its t-stat with Newey-West adjustment
intercept_series = pd.Series(period_interceptsFF1)
average_intercept = intercept_series.mean()

# Create a DataFrame for the regression of intercepts on a constant
intercept_df = pd.DataFrame({
    'intercept': intercept_series,
    'constant': 1  # Column of ones for the constant term
})

# Run a regression of period intercepts on a constant to estimate t-stat with Newey-West correction
intercept_model = sm.OLS(intercept_df['intercept'], intercept_df[['constant']]).fit()

# Calculate Newey-West covariance matrix
nw_cov = cov_hac(intercept_model, nlags=int(len(intercept_series)**(1/3)))  # Newey-West adjustment

# Calculate Newey-West-adjusted t-statistic for the intercept
intercept_t_stat = average_intercept / np.sqrt(nw_cov[0, 0])  # Use NW-adjusted standard error

# Store results in a DataFrame
results_FMB_df = pd.DataFrame([{
    'model': 'CAPM',
    'intercept': average_intercept,
    't-stat (intercept)': intercept_t_stat,
    'adj-R2': adjusted_r_squared,
}])
   